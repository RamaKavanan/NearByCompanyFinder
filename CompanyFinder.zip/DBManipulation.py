#!/usr/bin/python3

import sqlite3
from DBConnector import DBConnector

class DBManipulation(object):

	def __init__(self, connection):
		self.connection = connection
		
	# This prime focus to create table in runtime
	def create_table(self, table_string):
		if tableString:
			conn = self.connection
			cursor = conn.cursor()
			cursor.execute(table_string)
			print('Table created successfully ...')
		else:
			print('Table creation failed ...')
			raise Exception('Table creation string is empty')


	def many_insert_query_executor(self, query, listOfData):
		if query:
			if listOfData == None:
				raise Exception('Google Map data was empty ...')
			conn = self.connection
			cursor = conn.cursor()
			cursor.executemany(query, listOfData)
			conn.commit()
			return True
		else:
			raise Exception('Query string is empty')	

	def insert_query_executor(self, query):
		if query:
			conn = self.connection
			cursor = conn.cursor()
			cursor.execute(query)
			conn.commit()
			return True
		else:
			raise Exception('Query string is empty')

if __name__ == "__main__" :
	conn = DBManipulation('')

