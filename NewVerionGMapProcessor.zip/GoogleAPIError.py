#!/usr/bin/python3

class GoogleAPIError(Exception):
    pass

