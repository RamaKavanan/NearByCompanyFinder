#!/usr/bin/python3

import sqlite3
from DBConnector import DBConnector
from DBManipulation import DBManipulation
from ConsoleAPIRequest import ConsoleAPIRequest
import sys

class Application(object):

	BASE_URL = 'https://maps.googleapis.com/maps/api'
	PLACE_URL = BASE_URL + '/place'
	TEXT_SEARCH_API_URL = PLACE_URL + '/textsearch/json?'
	NEARBY_SEARCH_API_URL = PLACE_URL + '/nearbysearch/json?'
	RESPONSE_STATUS_OK = 'OK'

	def __init__(self, api_key):
		self._api_key = api_key
	
	@property
	def api_key(self):
        	return self._api_key

	def make_api_search(self, list_data, next_token, iterate_limit):
		try:
			api_request = ConsoleAPIRequest(self.api_key)
			geo_code = {'lat':'13.0145277', 'lng':'80.1981142'}
			query = 'software+company'
			response = api_request.company_search(self.TEXT_SEARCH_API_URL, query,geo_code,None,next_token)
			print('Response status',response.next_page_token)
			list_data.append(self.process_response(response, list_data))
			if response.has_next_page_token and iterate_limit <= 3 :
				iterate_limit += 1
				self.make_api_search(list_data, next_token, iterate_limit)
			return list_data
		except Exception as ex:
			raise Exception(str(ex))

	def process_response(self, response_data, list_data):
		try:
			for ele in response_data.results :
				c = (str(ele['formatted_address']),str(ele['geometry']),str(ele['icon']),str(ele['id']),str(ele['name']),str(ele['place_id']), str(ele['rating']) if 'rating' in ele.keys() else '',str(ele['reference']),str(ele['types']), str(ele['photos']) if 'photos' in ele.keys() else '',self.TEXT_SEARCH_API_URL)
				listData.append(c)
			return listData
		except Exception as ex:
			raise Exception(str(ex))
		
	def insert_data(query,listOfData, isNeedtable, tableString):
		connector = DBConnector('',"SoftCmpyInfoDB.db")
		conn = connector.create_schema()
		db_cmt = DBManipulation(conn)
		if isNeedtable :
			db_cmt.create_table(tableString)
		db_cmt.many_insert_query_executor(query, listOfData)

if __name__ == "__main__" :
	key = "AIzaSyAP10Oq3AJMhkFsWrN9OfR7HKPcr1li1_s"
	application = Application(key)
	listData = []
	dbDict = application.make_api_search(listData, None, 1)
	isNeedTable = sys.argv[1]
	tableString = "CREATE TABLE software_companies(   ID INTEGER PRIMARY KEY   AUTOINCREMENT,   address           TEXT,geometry TEXT, icon TEXT, google_id TEXT, name TEXT, place_id TEXT, rating TEXT, reference TEXT, types TEXT, photos TEXT, url TEXT)"
	query = "INSERT INTO software_companies (address,geometry, icon,google_id,name,place_id,rating,reference,types,photos,url) VALUES(?,?,?,?,?,?,?,?,?,?,?)"
	if isNeedTable == '1':
		Application.insert_data(query,listOfData, True, tableString)
	else:
		Application.insert_data(query,listOfData, False, tableString)
	#except Exception as ex:
		#print('Exception happen')
		#print(str(ex))
