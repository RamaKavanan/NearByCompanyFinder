#!/usr/bin/python3

class GooglePlacesError(Exception):
	pass

